association test
