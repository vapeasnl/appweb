document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript loaded');
});

