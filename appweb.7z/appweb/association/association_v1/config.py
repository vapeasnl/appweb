class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:01031991@localhost/association_v1_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'de5845838021615d5095bda09dc5613ae0931788fcfaf3c9'

